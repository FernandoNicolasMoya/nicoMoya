numero1=document.getElementById("numero1")
numero2=document.getElementById("numero2")
numero3=document.getElementById("resultado")
caja1=document.getElementById("caja1")
caja2=document.getElementById("caja2")
caja3=document.getElementById("caja3")


numero1.style="color: blue"
numero2.style="color: blue"
numero3.style="color: blue"


function suma(){
    suma= parseInt(caja1.value) + parseInt(caja2.value)
    caja3.setAttribute('value', suma)
    
}

function resta(){
    resta= parseInt(caja1.value) - parseInt(caja2.value)
    nada=0
    caja3.setAttribute('value', resta)
    caja1.setAttribute('value', nada)
    caja2.setAttribute('value', nada)
    
}

function multi(){
    multi= parseInt(caja1.value) * parseInt(caja2.value)
    caja3.setAttribute('value', multi)
    
}

function divi(){
    divi= parseInt(caja1.value) / parseInt(caja2.value)
    caja3.setAttribute('value', divi)
    
}
