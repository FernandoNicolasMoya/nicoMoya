//linea de comentario
/* bloque de 
    comentarios*/

//standar EMACS

/*

BOM : Browser Objet Model

DOM : Document Objet Model


*/

//BOM
console.log("hola mundo")
//alert("hola mundo JS")

//Lenguaje de tipado debil
x=2
x="hola"

console.log(x)

document.getElementById("titulo1").innerText="Hola mundo JS"
document.getElementById("titulo1").style="color: blue; text-align: center"


titulo2=document.getElementById("titulo2")

titulo2.innerText="Turno Noche"
titulo2.style="color: red; text-align: center"

caja1=document.getElementById("caja1")

caja1.innerHTML="<h1>caja1</h1>"
caja1.style="background-color: yellow; color: purple; padding: 5px; border-radius: 20px; text-align: center"

function rojo(){
    caja3.innerHTML="<h1>Rojo</h1>"
    caja3.style="color: white; background-color: red; text-align: center"
}

function verde(){
    caja3.innerHTML="<h1>Verde</h1>"
    caja3.style="color: white; background-color: green; text-align: center"
}

function azul(){
    caja3.innerHTML="<h1>Azul</h1>"
    caja3.style="color: white; background-color: blue; text-align: center"
}

